﻿using UnityEngine;

public static class Layers {
    public static readonly int Default = LayerMask.NameToLayer("Default");
}

