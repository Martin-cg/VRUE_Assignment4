public static class Utils {
    public static int RandomSeed() => UnityEngine.Random.Range(int.MinValue, int.MaxValue);
}
