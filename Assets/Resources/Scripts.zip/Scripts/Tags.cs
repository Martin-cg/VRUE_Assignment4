﻿public static class Tags {
    public const string Player = nameof(Player);
    public const string Respawn = nameof(Respawn);
    public const string EditorOnly = nameof(EditorOnly);
    public const string XROrigin = nameof(XROrigin);
    public const string RaceBarrier = nameof(RaceBarrier);
    public const string GoalTrigger = nameof(GoalTrigger);
    public const string Obstacle = nameof(Obstacle);
}
